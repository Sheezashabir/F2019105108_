window.addEventListener("load", function()
{
	let change= document.getElementById("change");
		let myHeading= document.getElementById("myHeading");
		let changeCss= document.getElementById("changeCss");
		let add= document.getElementById("add");
		let box=document.getElementById("box");
	change.addEventListener("click", function()

	{
   
			myHeading.innerHTML="Hello! My name is sheeza.";
	});
	changeCss.addEventListener("click", function()
	{
		myHeading.style.color="gray";
		myHeading.style.backgroundColor="red";
		myHeading.style.fontSize=44;
		myHeading.style.marginLeft= "66px";
	});
	
	let studentName = ["ONE" , "ALi" , "Ahmad" , "Faisal" , "ASD" , "XYZ"];
	add.addEventListener("click", function()
	{
	
            let newBox = document.createElement("div");
            newBox.className = "newBox";
			newBox.style.backgroundColor="gray";
			newBox.style.width="400px";
			newBox.style.height="400px";
            box.append(newBox);
			
        
	
	});
	
	let myForm= document.forms.myForm;
	myForm.addEventListener("submit", function()
	{
		let password= myForm.password.value;
		 cons
		if( password.length < 5 || password.length > 6)
		{
			alert("Invaild password! Please Try Again");
		}
	});
	
});