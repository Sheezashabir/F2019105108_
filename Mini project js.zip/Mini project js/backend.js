window.addEventListener("load", function()
{
	
	let b1=parseInt(document.getElementById('b1').value);
	let b2=parseInt(document.getElementById('b2').value);
	let b3=parseInt(document.getElementById('b3').value);
	let b4=parseInt(document.getElementById('b4').value);
	let b5=parseInt(document.getElementById('b5').value);
	let cal=document.getElementById('cal');
	let obt=document.getElementById('obt');
	cal.addEventListener("click", function()
	{
		if(b1>100 || b2>100 || b3>100 || b4>100 || b5>100)
		{
			alert("Invalid marks");
		}
		else
		{
		
		}
		
	});
	
});
/*function cal()
{
	var b1=parseInt(document.getElementById('b1').value);
	var b2=parseInt(document.getElementById('b2').value);
	var b3=parseInt(document.getElementById('b3').value);
	var b4=parseInt(document.getElementById('b4').value);
	var b5=parseInt(document.getElementById('b5').value);
	if(b1>100 || b2>100 || b3>100 || b4>100 || b5>100)
		{
			alert("Invalid marks");
		}
		else
		{
			var obt=b1+b2+b3+b4+b5;
			document.getElementById("obt").innerHTML= obt;
			var per=obt/500*100;
			document.getElementById("per").innerHTML=per;
			if(b1>40 || b2>40 || b3>40 || b4>40 || b5>40)
			{
				document.getElementById("rem").innerHTML= "Pass";
			}
			else
			{
				document.getElementById("rem").innerHTML= "Fail";
			}
			if(per>=80)
			{
				document.getElementById("gra").textContent= "A" ;
			}
			else if(per>=70)
			{
				document.getElementById("gra").textContent= "B" ;
			}
			else if(per>=60)
			{
				document.getElementById("gra").textContent= "C" ;
			}
			else if(per>=50)
			{
				document.getElementById("gra").textContent= "C-" ;
			}
			else
			{
				document.getElementById("gra").textContent= "F" ;
			}
				
			return false;
		}
		
}*/